package spring.web.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import spring.web.jpa.entity.User;

@Repository // 1. entity  , 2. entity type
public interface DataJpaRepository extends JpaRepository<User, Integer>{

}
