package spring.web.jpa.entity;

import java.util.Date;

import org.springframework.data.annotation.CreatedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor //매개변수가 없는 기본 생성자 자동 생성
@Table(name="USER1")
public class User {
	@Id
	@Column(name="user_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_gen")
	@SequenceGenerator(name = "user_gen", sequenceName = "user_seq", allocationSize = 1, initialValue = 1)
	private int userId;

	@Column(length=50)
	private String name;

	@Column(length=50)
	private String email;

	@Column(length=20)
	private String pw;
	
	@CreatedDate
	@Column(updatable=false,columnDefinition = "TIMESTAMP DEFAULT SYSDATE")
	private Date regdate;
}
