package spring.jpa.web.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import spring.jpa.web.entity.MemberEntity;

@Repository
public interface MemberRepository extends JpaRepository<MemberEntity, Integer> {
	
	// 로그인 처리 (리턴 타입 MemberEntity) 쿼리 메소드
	public MemberEntity findByIdAndPasswd(String id, String passwd);
	
	// 로그인 처리 (리턴 타입 MemberEntity) JPQL
	@Query("select m from MemberEntity m where m.id = :id and m.passwd = :passwd")
	public MemberEntity findByLogin(@Param("id") String id, @Param("passwd") String passwd);
	
	// 로그인 처리 (리턴 타입 int) 쿼리 메소드
	public int countByIdAndPasswd(String id, String passwd);
	
	// 로그인 처리 (리턴 타입 int) JPQL
	@Query("select count(m) from MemberEntity m where m.id = :id and m.passwd = :passwd")
	public MemberEntity countByLogin(@Param("id") String id, @Param("passwd") String passwd);
	
	
	
	
	
}
