package spring.jpa.web.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;
import spring.jpa.web.dto.MemberDTO;
import spring.jpa.web.service.MemberService;

@Controller
@RequestMapping("member/*")
public class MemberController {
	
	@Autowired
	MemberService service;
	
	@GetMapping("home")
	public String home() {
		
		return "member/main";
	}
	
	// 회원 가입 FORM
	@GetMapping("inputForm")
	public String inputForm() {
		
		return "member/inputForm";
	}
	
	@PostMapping("inputPro")
	public String inputPro(MemberDTO dto, Model model) {
		int result = service.memberAdd(dto);
		model.addAttribute("result", result);
		return "member/inputPro";
	}
	
	@GetMapping("loginForm")
	public String loginForm() {
		
		return "member/loginForm";
	}
	
	@PostMapping("loginPro")
	public String loginPro(@RequestParam("id") String id, 
					@RequestParam("passwd") String passwd,
					HttpSession session, Model model) {
		boolean result = service.memberLogin(id, passwd);
		
		if(result) {
			session.setAttribute("memId", id);
		}
		
		model.addAttribute("result", result);
		
		return "member/loginPro";
	}
	
//	@PostMapping("loginPro")
//	public String loginPro(MemberDTO dto) {
//		boolean result = service.memberLogin(dto.getId(), dto.getPasswd());
//		return "member/loginPro";
//	}
}



















