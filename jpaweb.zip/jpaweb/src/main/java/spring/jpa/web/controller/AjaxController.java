package spring.jpa.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AjaxController {

	@GetMapping("ajaxTest")
	public String ajaxTest() {
		return "ajax/ajaxTest";
	}

	@GetMapping("/ajax/getTest")
	@ResponseBody
	public String getTest(@RequestParam("message") String message) {
		return "Get수신: " + message;
	}

	@PostMapping("/ajax/postTest")
	@ResponseBody
	public String postTest(@RequestParam("message") String message) {
		return "Post수신: " + message;
	}
}
