package spring.jpa.web.service;
import org.springframework.stereotype.Service;
import spring.jpa.web.dto.MemberDTO;

@Service
public interface MemberService {
	
	public int memberAdd(MemberDTO dto);
	
	public boolean memberLogin(String id, String passwd);
}
