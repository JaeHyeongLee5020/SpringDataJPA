package spring.jpa.web.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.jpa.web.dto.MemberDTO;
import spring.jpa.web.entity.MemberEntity;
import spring.jpa.web.repository.MemberRepository;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	MemberRepository repository;

	@Override
	public int memberAdd(MemberDTO dto) {
		int result = 0;
		
		try {
			// MemberEntity 클래스에서 만든 MemberDTO를 MemberEntity로 변환하는 메서드 호출
			MemberEntity entity = MemberEntity.toMemberEntity(dto);
			repository.save(entity);
			result = 1;
		} catch(Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	@Override
	public boolean memberLogin(String id, String passwd) {
		boolean result = false;
		
		int count = repository.countByIdAndPasswd(id, passwd);
		MemberEntity entity = repository.findByIdAndPasswd(id, passwd);
		System.out.println("count : " + count);
		if(entity != null) {
			result = true;
		}
		
		return result;
	}
}















