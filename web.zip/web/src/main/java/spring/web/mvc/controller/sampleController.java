package spring.web.mvc.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import spring.web.mvc.bean.sampleDTO;

@Controller
public class sampleController {
	
	private static final Logger Logger = LoggerFactory.getLogger(sampleController.class);

	@RequestMapping("/mvc/test")
	public String test() {
		return "0422/test";
	}

	@GetMapping("mvc/login.do")
	public String loginForm() {
		return "0422/loginForm";
	}

	@PostMapping("mvc/login.do")
	public String loginPro() {
		return "0422/loginPro";
	}
	
	@RequestMapping("mvc/form")
	public String form() {
		return "0422/form";
	}
	
//	@RequestMapping("/mvc/main")
//	public String main(HttpServletRequest request) {
//		String name = request.getParameter("name");
//		String number = request.getParameter("name");
//		Logger.info("name :" + name );
//		Logger.info("number :" + number );
//		
//		
//		return "0422/main";
//	}

//	@RequestMapping("/mvc/main")
//	public String main(@RequestParam("name") String name, @RequestParam("number") int number) {
//		Logger.info("name :" + name);
//		Logger.info("number :" + number);
//		return "0422/main";
//	}
//	
	@RequestMapping("/mvc/main")
	public String main(sampleDTO dto) {
		Logger.info("name :" + dto.getName());
		Logger.info("number :" + dto.getNumber());
		return "0422/main";
	}
	
	
	
	
}
